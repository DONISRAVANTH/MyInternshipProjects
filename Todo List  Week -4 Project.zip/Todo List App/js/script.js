const inputField = document.querySelector(".input-field textarea"),
  todoLists = document.querySelector(".todoLists"),
  pendingNum = document.querySelector(".pending-num"),
  clearButton = document.querySelector(".clear-button");

document.addEventListener("DOMContentLoaded", () => {
  const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
  displayTasks(tasks);
});

function displayTasks(tasks) {
  todoLists.innerHTML = ""; 
  tasks.forEach((task, index) => {
    const liTag = `<li class="list ${task.completed ? 'completed' : 'pending'}" data-index="${index}">
      <span class="task">${task.name}</span>
      <button class="done-button" onclick="toggleCompletion(${index})">${task.completed ? 'Undo' : 'Done'}</button>
      <i class="uil uil-edit edit-button" onclick="editTask(${index})"></i>
      <i class="uil uil-trash delete-button" onclick="deleteTask(${index})"></i>
    </li>`;
    todoLists.insertAdjacentHTML("beforeend", liTag);
  });
  updatePendingNum();
}

function updatePendingNum() {
  const pendingTasks = document.querySelectorAll(".pending");
  pendingNum.textContent = pendingTasks.length;
}

inputField.addEventListener("keyup", (e) => {
  if (e.key === "Enter" && inputField.value.trim().length > 0) {
    const task = {
      name: inputField.value.trim(),
      completed: false
    };
    const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    tasks.push(task);
    localStorage.setItem("tasks", JSON.stringify(tasks));
    displayTasks(tasks);
    inputField.value = "";
  }
});

function toggleCompletion(index) {
  const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
  tasks[index].completed = !tasks[index].completed;
  localStorage.setItem("tasks", JSON.stringify(tasks));
  displayTasks(tasks);
}

function deleteTask(index) {
  const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
  tasks.splice(index, 1);
  localStorage.setItem("tasks", JSON.stringify(tasks));
  displayTasks(tasks);
}


function editTask(index) {
  const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
  const newName = prompt("Enter new task name:", tasks[index].name);
  if (newName !== null && newName.trim() !== "") {
    tasks[index].name = newName.trim();
    localStorage.setItem("tasks", JSON.stringify(tasks));
    displayTasks(tasks);
  }
}

clearButton.addEventListener("click", () => {
  localStorage.removeItem("tasks");
  displayTasks([]);
});
